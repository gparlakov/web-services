﻿using System;
using System.Linq;

namespace CodeJewels.Repository
{
    public interface IRepository
    {
    }
}
