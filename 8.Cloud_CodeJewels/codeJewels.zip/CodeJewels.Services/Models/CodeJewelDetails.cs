﻿namespace CodeJewels.Services.Models
{
    public class CodeJewelDetails : CodeJewelModel
    {
        public string AuthorEmail { get; set; }
    }
}