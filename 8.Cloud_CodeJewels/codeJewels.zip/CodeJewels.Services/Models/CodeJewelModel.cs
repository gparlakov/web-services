﻿namespace CodeJewels.Services.Models
{
    public class CodeJewelModel
    {
        public int Id { get; set; }

        public string Category { get; set; }

        public string Code { get; set; }
    }
}